% Orthoslice viewer with additional features
% Usage:
%   ibGUI - open GUI
%   ibGUI(3D_or_4D_matrix) - browse one matrix
%   ibGUI(a_struct) - browse a set of images
%         a_struct = struct('pO2', 3D_matrix, 'RAW', 4D_matrix, 'Mask',
%                            image_mask, ...);

% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago, JANUARY 2014
% Contact: epri.uchicago.edu

% Last Modified by GUIDE v2.5 30-Jan-2015 12:37:32
