% function epr_DrawAxis(hh, x, y, xy, xy_mask, xy_mask_add, guides, txt, opt)
% hh     - axis handle
% x,y,xy - 2D image xy and its axis
% xy_mask - image alpha mask, can be empty
% xy_mask_add - additional mask, can be empty
% guides  - [x,y] cross-guides to show some point in the image
% txt     - text shown in the lower bottom corner
% opt     - additional options structure
%     ext_mask  - 'transparency' or 'wire' - the way to display additional mask
%     clim      - [min,max] of image colormap
%     ShowGuide - 'no' for no guides or see plot function for linestyles
%     GuideLineWidth - linewidth of guides

% Boris Epel (c) 2007-2010
% University of Chicago
% bepel@uchicago.edu
