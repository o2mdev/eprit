function varargout = SetCoordinateSystem(varargin)
% SETCOORDINATESYSTEM MATLAB code for SetCoordinateSystem.fig
%      SETCOORDINATESYSTEM, by itself, creates a new SETCOORDINATESYSTEM or raises the existing
%      singleton*.
%
%      H = SETCOORDINATESYSTEM returns the handle to a new SETCOORDINATESYSTEM or the handle to
%      the existing singleton*.
%
%      SETCOORDINATESYSTEM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SETCOORDINATESYSTEM.M with the given input arguments.
%
%      SETCOORDINATESYSTEM('Property','Value',...) creates a new SETCOORDINATESYSTEM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SetCoordinateSystem_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SetCoordinateSystem_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SetCoordinateSystem

% Last Modified by GUIDE v2.5 30-Jan-2015 11:37:20
