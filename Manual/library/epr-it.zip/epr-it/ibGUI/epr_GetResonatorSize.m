% [sizeReson, mask] = epr_GetResonatorSize(resonType, matrix_size, FOV)
% resonType - '16mm'/'19mm'/'1inchSlotted'/'51.1x57.2mm'
% matrix_size and FOV - optional parameters for the mask generation
% mask - optional, mask of resonator volume
% Example: [res_dims, res_mask] = epr_GetResonatorSize('19mm', 64, 4.24);
