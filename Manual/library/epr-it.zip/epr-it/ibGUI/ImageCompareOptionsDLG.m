function varargout = ImageCompareOptionsDLG(varargin)
% IMAGECOMPAREOPTIONSDLG M-file for ImageCompareOptionsDLG.fig
%      IMAGECOMPAREOPTIONSDLG, by itself, creates a new IMAGECOMPAREOPTIONSDLG or raises the existing
%      singleton*.
%
%      H = IMAGECOMPAREOPTIONSDLG returns the handle to a new IMAGECOMPAREOPTIONSDLG or the handle to
%      the existing singleton*.
%
%      IMAGECOMPAREOPTIONSDLG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGECOMPAREOPTIONSDLG.M with the given input arguments.
%
%      IMAGECOMPAREOPTIONSDLG('Property','Value',...) creates a new IMAGECOMPAREOPTIONSDLG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ImageCompareOptionsDLG_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ImageCompareOptionsDLG_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ImageCompareOptionsDLG

% Last Modified by GUIDE v2.5 27-Jan-2015 09:51:12
