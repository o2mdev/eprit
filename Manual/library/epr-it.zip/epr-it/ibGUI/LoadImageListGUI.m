function varargout = LoadImageListGUI(varargin)
% LOADIMAGELISTGUI MATLAB code for LoadImageListGUI.fig
%      LOADIMAGELISTGUI, by itself, creates a new LOADIMAGELISTGUI or raises the existing
%      singleton*.
%
%      H = LOADIMAGELISTGUI returns the handle to a new LOADIMAGELISTGUI or the handle to
%      the existing singleton*.
%
%      LOADIMAGELISTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LOADIMAGELISTGUI.M with the given input arguments.
%
%      LOADIMAGELISTGUI('Property','Value',...) creates a new LOADIMAGELISTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before LoadImageListGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to LoadImageListGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help LoadImageListGUI

% Last Modified by GUIDE v2.5 24-Mar-2011 14:37:39
