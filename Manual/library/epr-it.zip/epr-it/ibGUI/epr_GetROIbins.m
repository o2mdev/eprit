% function [idx_roi, axis_roi, proj_xyz] = epr_GetROIbins(FOV, ROI, nbins, xyz)
% FOV - image field of view
% ROI - image region of interest
% nbins - number of bins in the image
% xyz - some point in the image bin coordianates
% idx_roi.x//.y//.z  - index of bins of ROI
% axis_roi.x//.y//.z - axis of ROI
% proj_xyz - some point in the image coordianates
% Example: 
%    [idx_roi, axis_roi, proj_xyz] = epr_GetROIbins(4, 3, 64, [32,32,32]);
