function varargout = SetCoordinateSystemDLG(varargin)
% SETCOORDINATESYSTEMDLG MATLAB code for SetCoordinateSystemDLG.fig
%      SETCOORDINATESYSTEMDLG, by itself, creates a new SETCOORDINATESYSTEMDLG or raises the existing
%      singleton*.
%
%      H = SETCOORDINATESYSTEMDLG returns the handle to a new SETCOORDINATESYSTEMDLG or the handle to
%      the existing singleton*.
%
%      SETCOORDINATESYSTEMDLG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SETCOORDINATESYSTEMDLG.M with the given input arguments.
%
%      SETCOORDINATESYSTEMDLG('Property','Value',...) creates a new SETCOORDINATESYSTEMDLG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SetCoordinateSystemDLG_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SetCoordinateSystemDLG_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SetCoordinateSystemDLG

% Last Modified by GUIDE v2.5 30-Jan-2015 13:03:12
