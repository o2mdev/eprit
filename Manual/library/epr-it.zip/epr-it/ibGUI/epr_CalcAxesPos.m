% function pst=epr_CalcAxesPos(row_num, col_num, gaps, sgaps)
% Calculate positions of plots on the figure
% row_num - number of rows
% col_num - number of columns
% gaps    - [horizontal, vertical] gap between plots (in parts of 1)
% sgaps   - [horizontal, vertical] border (in parts of 1)
%         - [horizontal_left, vertical_bottom, horizontal_right, vertical_top]
% use example:
% row_num = col_num = 4; 
% pst=epr_CalcAxesPos(row_num, col_num, [0.1,0.1], [0.1,0.1])
% for ii=1:row_num*col_num, hh(ii)=axes('Position', pst(ii,:)); end

% boep, 2008
