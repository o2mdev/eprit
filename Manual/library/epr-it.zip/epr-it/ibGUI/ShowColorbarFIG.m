% function ShowColorbarFIG(fig, type, min_max, varargin)
% fig  - fig number or axis or [] for new figure
% type - 'left'/'center'/'right'/'manual'
% arguments
%   'position' - axis position
