%GENERATE_IMAGE_COORDINATES  returns 3D arrays of x, y and z coordinates of image pixels
%
% inputs:  xlo, xhi, xcount   min and max x coordinate, number of pixels 
%          ylo, yhi, ycount   can take account of pixel size if you want.
%          zlo, zhi, zcount
% x is assumed to lie across image ROWS (second array index)
% y down image COLUMNS (first array index)
% z along image PAGE direction (third array index)
%
% outputs:  xout  3D array of x values - dimensions are (ycount, xcount, zcount).
%           yout
%           zout
%
% xout, yout, zout can be used as input to "interp3"

