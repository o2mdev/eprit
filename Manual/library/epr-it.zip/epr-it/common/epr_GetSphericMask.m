% Mask = epr_GetSphericMask(Dim, center, rad)
