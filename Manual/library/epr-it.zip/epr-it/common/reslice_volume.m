% reslices one image volume along the planes of another, using matrices
% saved by register_manual.  The saved matrices contain all the data
% necessary to map points back and forth from one image volume to the
% other.  The transformation is invertible, i.e. can be used in either
% direction.  However, the order of the two matrices does matter, and there
% is a "forward" and a "reverse" direction.  
%
% for a "forward" reslicing (direction >= 0):
%
% planevol (the first volume) defines the planes of the new volume
% imagevol (the second volume) is the image data to be resliced
% 
% for a "reverse" reslicing (direction < 0):
%
% planevol (first volume) is the image data
% imagevol (second volume) defines the planes of the new volume
%
% You must enter the volumes in the same order you did when you ran
% register_manual to generate the registration matrix.  For example, if you
% registered EPRI with MRI as follows:
%
% register_manual(mrivol, 'scale',mriscale,eprvol,'scale',eprscale)
%
% then you must run reslice_volume(hmat1, hmat2, mrivol, eprvol,...)
% to get correct results.  If you want to reslice the EPR onto the MRI
% planes, this would be a "forward" reslicing, i.e. direction=0 or 1.  If
% you want to reslice the MRI onto the EPR planes, this is a "reverse"
% reslicing, i.e. direction = -1.
%
% Voxels in the new volume that do not intersect the image data volume
% get the value "nullvalue".  You can set this to zero, or some large
% positive or negative value, depending on what you intend to do with the
% result.
%
% you can get the matrices from the saved registration file by using
%
% [hmat1,hmat2]=read_registration_matrix();
%
% note that this can be used to reslice not only actual image data, but
% also masks that represent regions of interest, as long as they are in the
% same pixel coordinate system as the image.
%
% C. Pelizzari August 2005
