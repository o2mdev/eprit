% finds the outside mask using largest component for a volume
% threshold defaults to 10% if not passed.
