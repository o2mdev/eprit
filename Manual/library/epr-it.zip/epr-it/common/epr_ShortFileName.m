% function strout = epr_ShortFileName(strin, nchars)
% Make file name shorter by removing the elements of the path