% IF Function
% res = iff(if_arg, a, b)
% if if_arg, res = a; else res = b; end
