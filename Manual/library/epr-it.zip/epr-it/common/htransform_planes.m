% takes a list of points (nplanes, 3, npoints) and a list of 4x4
% transfomations (4,4,nplanes) and applies the respective transformation to
% the points on each plane.  Where the transformations come from or what
% they are supposed to do is someone else's business.  We just plug and
% chug.
%
% C. Pelizzari Nov 07
