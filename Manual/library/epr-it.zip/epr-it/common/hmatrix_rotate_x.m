
%HMATRIX_ROTATE_X create homogeneous 4x4 matrix for rotation about X
%
% thet is in degrees
%  1.0 0.0 0.0   0.0
%  0.0  ct st    0.0
%  0.0 -st ct    0.0
%  0.0 0.0 0.0   1.0

