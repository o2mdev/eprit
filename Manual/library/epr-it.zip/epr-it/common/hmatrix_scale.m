%HMATRIX_SCALE create homogeneous 4x4 matrix from 1x3 scales

