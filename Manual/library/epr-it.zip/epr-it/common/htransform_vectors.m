
% HTRANSFORM_VECTORS
% apply the transformation "hmat" (4x4)
% to each vector in the list "invecs" (Nx3)
%
% calls "augment" to add a fourth column of ones,
% then applies the 4x4 hmat to the augmented vectors.
%
% note that our matrices are designed to be PRE multipled by
% the vectors, i.e., V' = V * A where V is the vector and A is
% the matrix.
%
% C. Pelizzari

