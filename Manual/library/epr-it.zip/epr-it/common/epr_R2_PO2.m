% function pO2 = epr_T2_PO2(T2, Amp, mask, pO2_info)
% convert T2 [us] to pO2 [torr] using constants from pO2_info structure