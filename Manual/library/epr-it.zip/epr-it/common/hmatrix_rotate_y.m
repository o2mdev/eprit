%HMATRIX_ROTATE_X create homogeneous 4x4 matrix for rotation about Y
%
% thet is in degrees
%  ct  0.0 -st    0.0
%  0.0 1.0 0.0   0.0
%  st 0.0 ct    0.0
%  0.0 0.0 0.0   1.0
