
% finds the connected components of the thresholded 2D image
% returns logical masks for each connected component in 
% sorted order, largest component first within a Cell Array
%
% to segment the largest component from the image, do this:
% comp=connected_components(image, thresh);
% then
%   segslice=image;
%   segslice(~comp{1})=0;
% or
%   segslice=image.*comp{1};
%
% if you want just the largest component, use
% comp=connected_components(image, thresh,1);
% C. Pelizzari August 2005
% ignores highest 1% of pixels and works on a
% normalized image CP&CH 01-25-07

% im2bw, bwmorph, bwlabel require 2D images
