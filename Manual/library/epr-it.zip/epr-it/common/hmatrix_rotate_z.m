%HMATRIX_ROTATE_X create homogeneous 4x4 matrix for rotation about Z
%
% thet is in degrees
%  ct  st  0.0   0.0
% -st  ct  0.0   0.0
%  0.0 0.0 1.0   0.0
%  0.0 0.0 0.0   1.0
