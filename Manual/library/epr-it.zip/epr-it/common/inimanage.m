% outstruct = inimanaging(filename)
% Reads and writes to 'ini'-files.
%    structure = inimanaging(filename)
%    inimanaging(filename, structure)
% The 'ini'-file style:
% [Options]
%     SingleValue1 = 122
%     SingleValue2 = hello
%     Array(1) = 123
%     Array(2) = 321
% Spaces in field and section names are not allowed.
% Single values are stored as strings, arrays as cell array of strings.
% boep
% AlSi 14.12.2004 for Kazan Viewer
