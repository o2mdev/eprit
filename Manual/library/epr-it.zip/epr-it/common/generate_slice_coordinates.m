%GENERATE_SLICE_COORDINATES  returns 2D arrays of x, y and z coordinates of pixels 
% on a 3D slice.
%
% inputs:  Corners(4,3)  3D coordinates of the 4 corners of the slice in order
%                        (upper left, upper right, lower right, lower left)
% 
% outputs: xout  (rows x columns) array of x coordinates
%          yout
%          zout
%
% xout, yout, zout can be used as input to "interp3"
% xout, yout can be used as input to "interp2" if we are sure we're on an
% original image plane.
