% create matrix for rotation by "ang" degrees about the direction
% "axis"
%
% Aug 08 - add optional point about which to rotate.  if third arg is
% specified and it is a vector, use it as the rotation center.
%
% C. Pelizzari
% Nov 07
