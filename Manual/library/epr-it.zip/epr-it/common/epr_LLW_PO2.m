% function pO2 = epr_LW_PO2(LLW, Amp, mask, pO2_info)
% convert LLW [mGauss] to pO2 [torr] using constants from pO2_info structure
