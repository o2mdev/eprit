% A = TumorTouchTransformation(TumorEllipsoid, m_dim_voxels, m_size_cm)
% Boris 
