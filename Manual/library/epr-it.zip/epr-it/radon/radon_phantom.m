% RADON_PHANTOM  Digital phantom generator
%  = struct('PhantomShape', 'Spherical', 'nBins', 128, 'matSizeCm', 4.24, 'r', 2.5/2, 'offset', [.5,.5,0]);
% [Ph_image] = RADON_PHANTOM(sphere);
%
%   See also RADON_C2D_SPHERE, RADON_C2D_CUBE.

% Author: Jayasai Rajagopal
% Center for EPR imaging in vivo physiology
% University of Chicago, 2015
% Contact: jrajagopal@uchicago.edu

