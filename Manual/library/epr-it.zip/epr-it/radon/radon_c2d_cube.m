% RADON_C2D_CUBE  analytic radon transformation of a sphere
% Phan = struct('PhantomShape', 'Spherical', 'nBins', 128, 'matSizeCm', 4.24, 'r', 2.5/2, 'offset', [.5,.5,0]);
% radon_pars = struct('Theta', theta, 'Phi', phi);
% [radon_pars.P, l, k] = RADON_C2D_CUBE(Phan, radon_pars);
%
%   See also RADON_C2D_SPHERE.

% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago, 2013
% Contact: epri.uchicago.edu
