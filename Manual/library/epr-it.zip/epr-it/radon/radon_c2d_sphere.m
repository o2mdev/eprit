% RADON_C2D_SPHERE  analytic Radon transformation of a sphere
% [P] = RADON_C2D_SPHERE(Phan, radon_pars);
% [r,P] = RADON_C2D_SPHERE(Phan, radon_pars);
% Phan - Phantom structure
%   r - sphere radius [cm]
%   offset - offset of sphere from center [cm]
%   nBins - length of array
% radon_pars - radon transformation parameters structure
%   x,y,z - vectors of unit vector coordinates
%   size - length of resulting projection [cm]
%
%   See also RADON_C2D_CUBE.

% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago, 2013
% Contact: epri.uchicago.edu
