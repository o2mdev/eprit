%RADON_D2D - 3D radon transformation
% [pr, r] = RADON_D2D(M, marix_size, radon_pars)
% M - 3D matrix of an object
% marix_size - matrix size in [cm]
% radon_radon_pars - structure of parameters
%   x,y,z arrays of unit vector projections on coordinate axis
%   nSubBins - each voxel will be brocken into 2^3 subvoxels prior to projetion 
%
%   See also RADON_ANGLE2XYZ.

% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago, 2013
% Contact: epri.uchicago.edu
