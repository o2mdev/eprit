
%**********************************************************************************
% Function: reconstruction software, which can reconstruct a 3-D object from projections
% Formula: 3-D inverse radon transform
% Implementation method: single stage, which is the standard back-projection method.
%***********************************************************************************
%
%
%
%***********************************************************************************
% object: the 3-D reconstructed object, is a 3-D array. the number of every dimension should be the same. For example it's size is [128 128 128]
% p: a 2-D array, row number=points number of every projection; colum number= number of projections
% radon_pars.x: unit direction vector's x coordination,a 1-D array,whose length is the number of the projections
% radon_pars.y: unit direction vector's y coordination,a 1-D array,whose length is the number of the projections
% radon_pars.z: unit direction vector's z coordination,a 1-D array,whose length is the number of the projections
% radon_pars.w: the weighting factors of all the projections,a 1-D array, whos length is the number of the projections
% radon_pars.size: the length(cm) of the projection
% recon_pars.nBins: the length of the side of the cube. For example, the final image is 128*128*128, then nBins=128
% recon_pars.FilterCutOff: the bandwidth of the using low-pass filter. the range is [0 1], 0 means all the frequency components are blocked. 1 means all pass.
% recon_pars.size: the length(cm) of the side of the cube. For example, the final image is 5cm*5cm*5cm, then lengthBins=5
% recon_pars.display: 0 means to not displaying the intermediate result; 1 means to display the result
% recon_pars.processor: 1 is CPU; 2 is GPU
% recon_pars.Filter: 1 is 2rd derivative; 2 is using 3-points derivative method; 3 is using two S-L Ramp filter.
% recon_pars.interp_method: 0 is zero-rank interpolation method; 1 is linear interpolation method. 2 is spline interpolation method. Note that for GPU method, you can just select 0 or 1;
% recon_pars.tasksliced: (GPU ONLY )1 means that the back projction process is divided  into many small tasks; 0 means there just is one whole task.
%**********************************************************************************


%***********************************************************************************
% Author: ZHIWEI QIAO
% Center for EPR imaging in vivo physiology
% University of Chicago, JULY,2013
% Contact: zqiao1@uchicago.edu
%***********************************************************************************






