% IRADON_D2D_MSTAGE  reconstuct a 3D or 4D object from 1D projections
% [object] = iradon_d2d_mstage(p, radon_pars, recon_pars);
% Algorithm: multi_stage backprojection method
% Projeciton sampling method: equal angle
% Number of bins in reconstructed matrix in all dimensions is equal
% to the number of points in projections
% p - [array, 4D] of projections
%     for 3D - size(p)=[points_in_projection, 1, nTheta, nPhi]
%     for 4D - size(p)=[points_in_projection, nTheta, nPhi, nAlpha]
% radon_pars - [structure] projection parameters
%     [].ELA - [structure] of equal angle gradient scheme parameters
%            [].imtype - Image type [int, 1 for 4D, 14 for 3D]
%            [].nPolar - Number of polar angles [int]
%            [].nAz    - Number of azimuthal angles [int]
%            [].nSpec  - Number of spectral angles[int]
%     [].size - length of the spacial projection [float, in cm]
% recon_pars - [structure] reconstruction parameters
%     [].nBins  - Image size in voxels [int]
%     [].Filter - [string, ram_lak/shepp-logan/cosine/hamming/hann]
%     [].FilterCutOff  - Filter cut off, part of full bandwidth [float, 0 to 1]
%     [].InterpFactor  - Projection interpolation factor, [int, 1/2/4/etc]
%     [].Interpolation - Inerpolation method, [string, (none)/sinc/spline/linear]
%     [].CodeFlag      - Reconstruction code [string, C/MATLAB/FORTRAN]
%     [].zeropadding   - zeropadding factor [int, >= 1]
% object - reconstructed object

% Author: Boris Epel
% For authors of reconstruction see inside Recon_AI_Filt_BP.m
% Center for EPR imaging in vivo physiology
% University of Chicago,JULY 2013
% Contact: epri.uchicago.edu
