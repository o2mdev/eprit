% MATRIXGUI MATLAB code for MatrixGUI.fig
%      MATRIXGUI, by itself, creates a new MATRIXGUI or raises the existing
%      singleton*.
%
%      H = MATRIXGUI returns the handle to a new MATRIXGUI or the handle to
%      the existing singleton*.
%
%      MATRIXGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MATRIXGUI.M with the given input arguments.
%
%      MATRIXGUI('Property','Value',...) creates a new MATRIXGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MatrixGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MatrixGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MatrixGUI

% Last Modified by GUIDE v2.5 04-Sep-2014 16:07:50

% Begin initialization code - DO NOT EDIT
