% IRADON_ZEROPADDING   zeropadding of the data first dimension
% function [Pzp, zeropadding] = iradon_zeropadding(P, zeropadding)
% P           - Data, [array, any dimensions]
% zeropadding - Zeropadding factor [int, >= 1]
% Pzp         - Output data [array, any dimensions]


% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago,JULY 2013
% Contact: epri.uchicago.edu
