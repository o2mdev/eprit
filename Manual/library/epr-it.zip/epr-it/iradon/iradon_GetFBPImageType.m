% IRADON_GETFBPIMAGETYPE returns numerical and string representation of
% image type
% [nimtype, simtype] = iradon_GetFBPImageType(imtype);
% imtype - Image type [int, 1 to 14]
%            or
%        - Image type [XB/YB/ZB/XYB/XZB/YZB/XYZB/ X/Y/Z/XY/XZ/YZ/XYZ]
% nimage  - Image type [int, 1 to 14]
% simtype - Image type [XB/YB/ZB/XYB/XZB/YZB/XYZB/ X/Y/Z/XY/XZ/YZ/XYZ]
% 
% See also IRADON_FBP_GRAD_TABLE
