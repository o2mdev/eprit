% IRADON_FBPGRADTABLE uniform angular and uniform spatial gradient table
% for FBP images
% [out, suplementary_out] = iradon_FBP_grad_table(FBP)
% FBP - [structure] of gradient scheme parameters
%   [].imtype - Image type [int, 1 for 4D, 14 for 3D]
%   [].nPolar - Number of polar angles [int]
%   [].nAz    - Number of azimuthal angles [int]
%   [].nSpec  - Number of spectral angles[int]
%   [].size - length of the spatial projection [float, in cm]
%   [].CoordPole - [1/2/3] or <X/Y/(Z)>
%   [].MaxGradient - Maximum gradient [float, in G/cm]
%   [].angle_sampling - type of angle sampling
%       UNIFORM_ANGULAR  - uniform angular
%       UNIFORM_ANGULAR_FLIP - uniform angular with optimized jumps
%       UNIFORM_SPATIAL_FLIP - uniform solid angle with optim. jumps
% out - [structure] of radon transformation parameters
%   [].GradX - Gradient component [array, 1D]
%   [].GradY - Gradient component [array, 1D]
%   [].GradZ - Gradient component [array, 1D]
% suplementary_out - [structure] of radon transformation parameters
%   [].kx - k-space unit vector component [array, 1D]
%   [].ky - k-space unit vector component [array, 1D]
%   [].kz - k-space unit vector component [array, 1D]
%   [].w  - projection weight factor [array, 1D]
% 
% See also IRADON_GETFBPIMAGETYPE

% Author: Boris Epel
% Center for EPR imaging in vivo physiology
% University of Chicago,JULY 2013
% Contact: epri.uchicago.edu
