% pars = iradon_baseline(opt)
% opt.baseline  - type of b/l corection
%       BEFORE
%       AFTER
%       BEFORE_AFTER
%       EVERY_N  - b/l recorded for every n (= opt.bl_n) projection
% opt.bl_n      - parameter used in EVERY_N baseline correction
