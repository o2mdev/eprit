% IRADON_VOR_AREA_3D   calculate voronoi area on surface of sphere
% [areas] = iradon_vor_area_3d(kx,ky,kz);
% kx,ky,kz - k-space direction vector coordinates [double array]
% areas    - surface area on unit sphere occupied by the points
% Algorithm: Find (dtheta)*(dphi) by converting cartesian points (Gx,Gy,Gz)
%   to spherical coordinates, treating points on 2D grid of theta = 0 to pi/2
%   and phi = 0 to 2pi, and calculating voronoi area on grid. Multiply areas
%   by sin(theta) to get 'areas' (surface areas on sphere)

% Author: Gage Redler
% Center for EPR imaging in vivo physiology
% University of Chicago,OCTOBER 2013
% Contact: epri.uchicago.edu
